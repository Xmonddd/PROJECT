<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .form-container {
            margin-top: 100px;
            background: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .form h2 {
            margin-bottom: 10px;
            color: #343a40;
        }
        .form p {
            font-size: 14px;
            color: #6c757d;
        }
        .form-control {
            border-radius: 8px;
        }
        .form-control.button {
            background-color: #007bff;
            color: #fff;
            transition: background-color 0.3s;
        }
        .form-control.button:hover {
            background-color: #0056b3;
        }
        .alert {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="col-md-6 col-lg-5 form-container">
            <form action="forgot-password.php" method="POST" autocomplete="">
                <h2 class="text-center">Forgot Password</h2>
                <p class="text-center">Enter your email address to reset your password.</p>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger text-center">
                        <?php 
                            foreach($errors as $error){
                                echo $error;
                            }
                        ?>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <input class="form-control" type="email" name="email" placeholder="Enter email address" required value="<?php echo $email ?>">
                </div>
                <div class="form-group">
                    <input class="form-control button" type="submit" name="check-email" value="Continue">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
