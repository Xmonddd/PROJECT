<?php
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    session_start();
    if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
        header("Location: index.php");
        exit();
    }

    $postIdToDelete = $_GET['id'];
    $conn = new mysqli("localhost", "root", "", "agrishop");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param("i", $postIdToDelete);

    if ($stmt->execute()) {
        // Deletion successful, redirect back to the admin posts page
        header("Location: adminpostpanel.php");
        exit();
    } else {
        echo "Error deleting post: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    // Invalid or missing post ID
    header("Location: adminpostpanel.php");
    exit();
}
?>