<?php
if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
    http_response_code(403); // Forbidden
    exit('Access Denied');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli("localhost", "root", "", "agrishop");
    if ($conn->connect_error) {
        http_response_code(500); // Internal Server Error
        exit("Connection failed: " . $conn->connect_error);
    }

    $user_id = $_POST['id'] ?? null;
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';

    if ($user_id !== null && is_numeric($user_id)) {
        $fullname = trim($first_name . ' ' . $last_name);

        $stmt = $conn->prepare("UPDATE users SET fullname = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $fullname, $email, $user_id);

        if ($stmt->execute()) {
            echo 'success';
        } else {
            echo 'error';
        }

        $stmt->close();
    } else {
        echo 'error';
    }

    $conn->close();
} else {
    http_response_code(400); // Bad Request
    exit('Invalid request method');
}
?>