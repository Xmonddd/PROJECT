<?php


include("functions.php");

// PHP goes here!

?>

    <!-- Header section  -->
<?php include("login1.php") ?>

    <!-- Main section  
    <div class="container12">
        <h1>Welcome to AgriShop: Farm Online Website</h1>
    </div>
            -->
    <!-- Footer section  -->
<?php include("footer.php") 

?>

