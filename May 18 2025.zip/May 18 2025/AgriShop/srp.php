<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Fetch user profile information
$sql_user = "SELECT fullname, profile_image FROM users WHERE username = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("s", $username);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user_data = $result_user->fetch_assoc();

$fullname = $user_data['fullname'];
$profile_image = !empty($user_data['profile_image']) ? htmlspecialchars($user_data['profile_image']) : 'uploads/default.png';

$conn->close();



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop: Farm Online Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
   
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">AgriShop: Farm Online Website</a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="srp.php"><i class="fas fa-home"></i> HOME</a></li> 
                <li><a href="buying.php"><i class="fas fa-shopping-cart"></i> PURCHASE</a></li>
                <li><a href="selling.php"><i class="fas fa-tag"></i> SELL</a></li>
                <li><a href="mainhome.php"><i class="fas fa-home"></i> TRANSACT</a></li>
                <li><a href="message.php"><i class="fas fa-envelope fa-2x"></i></a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo $profile_image; ?>" alt="Profile" class="profile-pic-nav"> <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
           
                </li>
                         
                    
            </ul>
        </div>
    </div>
</nav>





<h2 style="text-align:center;margin:30px 0 20px;">Suggested Retail Price (SRP)</h2>
<div class="container1" style="display:flex;flex-wrap:wrap;gap:20px;justify-content:center;">
  <?php
    // Example array, replace min_price/max_price and images as needed
    $products = [
      [
        'name' => 'Rice',
        'image' => 'srp/rice.jpg',
        'weight' => '1kg',
        'min_price' => 45.00,
        'max_price' => 55.00
      ],
      [
        'name' => 'Corn',
        'image' => 'srp/corn.jpg',
        'weight' => 'kg',
        'min_price' => 30.00,
        'max_price' => 40.00
      ],
      [
        'name' => 'Mango',
        'image' => 'srp/mango.jpeg',
        'weight' => 'kg',
        'min_price' => 80.00,
        'max_price' => 120.00
      ],
      [
        'name' => 'Tomato',
        'image' => 'srp/tomato.jpg',
        'weight' => '1kg',
        'min_price' => 60.00,
        'max_price' => 80.00
      ],
      [
        'name' => 'Onion',
        'image' => 'srp/onion.jpg',
        'weight' => 'kg',
        'min_price' => 70.00,
        'max_price' => 90.00
      ],
      [
        'name' => 'Sweet Potato',
        'image' => 'srp/sweet_potato.jpg',
        'weight' => 'kg',
        'min_price' => 25.00,
        'max_price' => 35.00
      ],
      [
        'name' => 'Cabbage',
        'image' => 'srp/cabbage.jpg',
        'weight' => 'kg',
        'min_price' => 40.00,
        'max_price' => 50.00
      ],
      [
        'name' => 'Carrot',
        'image' => 'srp/carrot.jpg',
        'weight' => 'kg',
        'min_price' => 55.00,
        'max_price' => 65.00
      ],
      [
        'name' => 'Banana (Saba)',
        'image' => 'srp/banana.jpg',
        'weight' => 'kg',
        'min_price' => 20.00,
        'max_price' => 30.00
      ],
      [
        'name' => 'Eggplant',
        'image' => 'srp/eggplant.jpg',
        'weight' => 'kg',
        'min_price' => 35.00,
        'max_price' => 45.00
      ],
      [
        'name' => 'Green Beans',
        'image' => 'srp/green_beans.jpg',
        'weight' => 'kg',
        'min_price' => 60.00,
        'max_price' => 75.00
      ],
      [
        'name' => 'Watermelon',
        'image' => 'srp/watermelon.jpg',
        'weight' => 'kg',
        'min_price' => 30.00,
        'max_price' => 40.00
      ],
      [
        'name' => 'Pineapple',
        'image' => 'srp/pineapple.jpg',
        'weight' => 'kg',
        'min_price' => 45.00,
        'max_price' => 55.00
      ],
      [
        'name' => 'Papaya',
        'image' => 'srp/papaya.jpg',
        'weight' => 'kg',
        'min_price' => 35.00,
        'max_price' => 45.00
      ],
      [
        'name' => 'Ginger',
        'image' => 'srp/ginger.jpg',
        'weight' => 'kg',
        'min_price' => 120.00,
        'max_price' => 150.00
      ]
    ];

    foreach ($products as $product) {
      echo '<div class="card" style="background:white;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);width:220px;overflow:hidden;text-align:center;padding-bottom:15px;transition:transform 0.2s;">';
      echo '<img src="' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['name']) . '" style="width:100%;height:200px;object-fit:cover;border-bottom:1px solid #ddd;">';
      echo '<h3 style="margin:10px 0 5px;font-size:16px;">' . htmlspecialchars($product['name']) . ' <small>' . htmlspecialchars($product['weight']) . '</small></h3>';
      echo '<p class="price" style="margin:0;font-weight:bold;color:#2a8b2a;">₱ ' 
           . number_format($product['min_price'], 2) . ' – ₱ ' 
           . number_format($product['max_price'], 2) 
           . ' / kilogram</p>';
      echo '</div>';
    }
  ?>
</div>