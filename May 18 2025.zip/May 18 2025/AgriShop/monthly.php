<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
    header("Location: index.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'] ?? null;

if ($username && (!isset($_SESSION['profile_image']) || !isset($_SESSION['fullname']))) {
    $stmt = $conn->prepare("SELECT fullname, profile_image FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['profile_image'] = $user['profile_image'] ?? 'uploads/default.png';
    }
    $stmt->close();
}

$profile_from_session = $_SESSION['profile_image'] ?? 'uploads/default.png';
$user_profile_image = (strpos($profile_from_session, 'uploads/') === false)
    ? 'uploads/' . $profile_from_session
    : $profile_from_session;

$user_fullname = $_SESSION['fullname'] ?? 'Guest User';

// Fetch Monthly Post Statistics
$monthly_stats = [];
$months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
for ($month = 1; $month <= 12; $month++) {
    $month_str = sprintf("%02d", $month); // Add leading zero if needed
    $year_month = date('Y') . '-' . $month_str;

    $stats = [
        'total' => 0,
        'buying' => 0,
        'selling' => 0,
        'available' => 0,
        'sold' => 0
    ];

    // Total posts
    $query = "SELECT COUNT(id) AS count FROM mainpost WHERE DATE_FORMAT(created_at, '%Y-%m') = '$year_month'";
    $result = $conn->query($query);
    if ($result) {
        $stats['total'] = $result->fetch_assoc()['count'] ?? 0;
        $result->free_result();
    } else {
        echo "Error fetching total posts for $year_month: " . $conn->error;
    }

    // Buying posts
    $query = "SELECT COUNT(id) AS count FROM mainpost WHERE category = 'buying' AND DATE_FORMAT(created_at, '%Y-%m') = '$year_month'";
    $result = $conn->query($query);
    if ($result) {
        $stats['buying'] = $result->fetch_assoc()['count'] ?? 0;
        $result->free_result();
    } else {
        echo "Error fetching buying posts for $year_month: " . $conn->error;
    }

    // Selling posts
    $query = "SELECT COUNT(id) AS count FROM mainpost WHERE category = 'selling' AND DATE_FORMAT(created_at, '%Y-%m') = '$year_month'";
    $result = $conn->query($query);
    if ($result) {
        $stats['selling'] = $result->fetch_assoc()['count'] ?? 0;
        $result->free_result();
    } else {
        echo "Error fetching selling posts for $year_month: " . $conn->error;
    }

    // Available posts
    $query = "SELECT COUNT(id) AS count FROM posts WHERE status = 'available' AND DATE_FORMAT(created_at, '%Y-%m') = '$year_month'";
    $result = $conn->query($query);
    if ($result) {
        $stats['available'] = $result->fetch_assoc()['count'] ?? 0;
        $result->free_result();
    } else {
        echo "Error fetching available posts for $year_month: " . $conn->error;
    }

    // Sold posts
    $query = "SELECT COUNT(id) AS count FROM posts WHERE status = 'sold' AND DATE_FORMAT(created_at, '%Y-%m') = '$year_month'";
    $result = $conn->query($query);
    if ($result) {
        $stats['sold'] = $result->fetch_assoc()['count'] ?? 0;
        $result->free_result();
    } else {
        echo "Error fetching sold posts for $year_month: " . $conn->error;
    }

    $monthly_stats[] = $stats;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop: Monthly Statistics</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f8f9fa; /* Very light gray background */
            color: #495057; /* Slightly softer dark gray text */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .content-container {
            flex: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #343a40;
            margin-top: 0;
            margin-bottom: 1.5rem;
            font-size: 2rem;
            font-weight: 400;
            text-align: center;
        }

        .monthly-stats-table {
            width: 90%;
            border-collapse: collapse;
            margin-top: 1rem;
            margin-bottom: 2rem;
            border: 1px solid #dee2e6; /* Light gray border */
            border-radius: 0.25rem; /* Slightly rounded corners */
            overflow: hidden; /* To contain rounded corners */
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); /* Subtle shadow */
            background-color: #fff;
        }

        .monthly-stats-table th,
        .monthly-stats-table td {
            padding: 0.75rem;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }

        .monthly-stats-table th {
            background-color: #f8f9fa; /* Very light gray header */
            font-weight: 500;
            color: #343a40;
        }

        .monthly-stats-table tbody tr:hover {
            background-color: #f5f5f5; /* Light hover effect */
        }

        .chart-container {
            display: none; /* Initially hide the chart container */
            position: fixed; /* For the pop-up effect */
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 15px; /* Reduced padding */
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Subtler shadow */
            z-index: 1001; /* Ensure it's on top */
            width: 85%; /* Slightly smaller container */
            height: 75%; /* Slightly smaller container */
            max-width: 90%;
            max-height: 85%;
            border-radius: 8px; /* Less pronounced rounded corners */
            overflow: hidden; /* Clip content if needed */
        }

        .chart-container h2 {
            margin-top: 0;
            margin-bottom: 0.8rem; /* Further reduced bottom margin */
            font-size: 1.6rem; /* Even smaller heading */
            color: #555; /* Softer heading color */
            text-align: center;
        }

        .close-chart {
            position: absolute;
            top: 10px; /* Adjust top position */
            right: 10px; /* Adjust right position */
            width: 23px;
            height: 23px;
            border: 2px solid #eef5df;
            background-color: #ff5248;
            border-radius: 50%;
            cursor: pointer;
        }

        .close-chart::before,
        .close-chart::after {
            position: absolute;
            top: 10px;
            left: 5px;
            width: 13px;
            height: 3px;
            content: "";
            background-color: #eef5df;
        }

        .close-chart::before {
            transform: rotate(-45deg);
        }

        .close-chart::after {
            transform: rotate(45deg);
        }

        .close-chart:hover::before,
        .close-chart:hover::after {
            display: block; /* Ensure they are visible on hover */
        }

        #monthlyStatsChart {
            width: 100%; /* Fill the container */
            height: calc(100% - 40px); /* Adjust height for smaller heading and close button */
            margin: 0 auto;
            display: block;
        }

        footer {
            background-color: #fff;
            padding: 1rem 0;
            text-align: center;
            color: #6c757d;
            border-top: 1px solid #e9ecef;
            margin-top: auto;
        }

        footer a {
            color:rgb(77, 78, 78);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        .show-chart-button {
            position: relative;
            display: inline-block;
            cursor: pointer;
            outline: none;
            border: 0;
            vertical-align: middle;
            text-decoration: none;
            background: transparent;
            padding: 0;
            font-size: inherit;
            font-family: inherit;
            width: 12rem; /* Adjust width as needed */
            height: auto;
            margin-top: 1rem; /* Keep the top margin */
        }

        .show-chart-button .circle {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            position: relative;
            display: block;
            margin: 0;
            width: 3rem;
            height: 4rem;
            background: #282936; /* Dark background color */
            border-radius: 1.625rem;
        }

        .show-chart-button .circle .icon {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            position: absolute;
            top: 0;
            bottom: 0;
            margin: auto;
            background: #fff; /* White arrow */
        }

        .show-chart-button .circle .icon.arrow {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            left: 0.625rem;
            width: 1.125rem;
            height: 0.125rem;
            background: none;
        }

        .show-chart-button .circle .icon.arrow::before {
            position: absolute;
            content: "";
            top: -0.29rem;
            right: 0.0625rem;
            width: 0.625rem;
            height: 0.625rem;
            border-top: 0.125rem solid #fff;
            border-right: 0.125rem solid #fff;
            transform: rotate(45deg);
        }

        .show-chart-button .button-text {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            padding: 0.75rem 0;
            margin: 0 0 0 1.85rem;
            color: #282936; /* Dark text color */
            font-weight: 700;
            line-height: 1.6;
            text-align: center;
            text-transform: uppercase;
            font-size: 0.9rem; /* Adjust font size to match previous */
        }

        .show-chart-button:hover .circle {
            width: 100%;
        }

        .show-chart-button:hover .circle .icon.arrow {
            background: #fff;
            transform: translate(1rem, 0);
        }

        .show-chart-button:hover .button-text {
            color: #fff;
        }

        #monthlyStatsChart {
            width: calc(100% - 20px); /* Make the canvas fill the container with some padding */
            height: calc(100% - 60px); /* Adjust height for heading and some spacing */
            margin: 0 auto; /* Center the chart within the container */
            display: block; /* Prevent extra spacing below the canvas */
        }
    </style>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">AgriShop: Farm Online Website</a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="adminpage.php"><i class="fas fa-arrow-left"></i> Back to Users</a></li>
                <li><a href="profile.php"><img src="<?php echo htmlspecialchars($user_profile_image); ?>" class="profile-pic-nav" alt="Profile"></a></li>
                <li>
                    <a href="#" onclick="confirmLogout()">
                        <i class="fas fa-sign-out-alt fa-lg"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="content-container">
    <h2>Monthly Post Statistics</h2>
    <table class="monthly-stats-table">
        <thead>
            <tr>
                <th>Month</th>
                <th>Total Posts</th>
                <th>Buying</th>
                <th>Selling</th>
                <th>Available</th>
                <th>Sold</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($monthly_stats as $index => $stats):
            ?>
                <tr>
                    <td><?php echo $months[$index]; ?></td>
                    <td><?php echo $stats['total']; ?></td>
                    <td><?php echo $stats['buying']; ?></td>
                    <td><?php echo $stats['selling']; ?></td>
                    <td><?php echo $stats['available']; ?></td>
                    <td><?php echo $stats['sold']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <button class="show-chart-button" onclick="showChart()">
        <span class="circle" aria-hidden="true"><span class="icon arrow"></span>
        </span>
        <span class="button-text">Show Monthly Graph</span>
    </button>

    <div class="chart-container" id="monthlyStatsChartContainer">
        <h2>Monthly Post Statistics Graph</h2>
        <button class="close-chart" onclick="hideChart()"></button>
        <canvas id="monthlyStatsChart"></canvas>
    </div>
</div>

<?php include("footer.php"); ?>

<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = "logout.php";
        }
    }

    // Monthly statistics data from PHP
    const monthlyStats = <?php echo json_encode($monthly_stats); ?>;
    const monthsLabels = <?php echo json_encode($months); ?>;
    const chartContainer = document.getElementById('monthlyStatsChartContainer');
    const chartCanvas = document.getElementById('monthlyStatsChart');
    let monthlyChart;

    function showChart() {
        chartContainer.style.display = 'block';
        if (!monthlyChart) {
            const ctx = chartCanvas.getContext('2d');
            monthlyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: monthsLabels,
                    datasets: [{
                        label: 'Total Posts',
                        data: monthlyStats.map(data => data.total),
                        backgroundColor: 'rgba(54, 162, 235, 0.7)', // Blue
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }, {
                        label: 'Buying Posts',
                        data: monthlyStats.map(data => data.buying),
                        backgroundColor: 'rgba(255, 99, 132, 0.7)', // Red
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }, {
                        label: 'Selling Posts',
                        data: monthlyStats.map(data => data.selling),
                        backgroundColor: 'rgba(255, 206, 86, 0.7)', // Yellow
                        borderColor: 'rgba(255, 206, 86, 1)',
                        borderWidth: 1
                    }, {
                        label: 'Available Posts',
                        data: monthlyStats.map(data => data.available),
                        backgroundColor: 'rgba(75, 192, 192, 0.7)', // Green
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }, {
                        label: 'Sold Posts',
                        data: monthlyStats.map(data => data.sold),
                        backgroundColor: 'rgba(153, 102, 255, 0.7)', // Purple
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Posts'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Month'
                            }
                        }
                    },
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    function hideChart() {
        chartContainer.style.display = 'none';
    }
</script>

</body>
</html>