<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
    header("Location: index.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'] ?? null;

if ($username && (!isset($_SESSION['profile_image']) || !isset($_SESSION['fullname']))) {
    $stmt = $conn->prepare("SELECT fullname, profile_image FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['profile_image'] = $user['profile_image'] ?? 'uploads/default.png';
    }
    $stmt->close();
}

$profile_from_session = $_SESSION['profile_image'] ?? 'uploads/default.png';
$user_profile_image = (strpos($profile_from_session, 'uploads/') === false)
    ? 'uploads/' . $profile_from_session
    : $profile_from_session;

$user_fullname = $_SESSION['fullname'] ?? 'Guest User';

// Pagination settings
$limit = 10; // Show only 3 posts per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Fetch total number of posts
$total_posts_query = "SELECT COUNT(id) AS total FROM posts";
$total_result = $conn->query($total_posts_query);
if ($total_result) {
    $total_posts = $total_result->fetch_assoc()['total'] ?? 0;
    $total_pages = ceil($total_posts / $limit);
} else {
    echo "Error fetching total posts: " . $conn->error;
    $total_posts = 0;
    $total_pages = 0;
}

// Fetch posts for the current page
$sql = "SELECT p.*, u.fullname, u.profile_image
        FROM posts p
        JOIN users u ON p.username = u.username
        ORDER BY p.created_at DESC
        LIMIT $start, $limit";
$result = $conn->query($sql);
$posts_data = [];
if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $posts_data[] = $row;
        }
    }
    $result->free_result();
} else {
    echo "Error fetching posts: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop: Farm Online Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <style>
        body {
            display: flex;
            flex-direction: column;
            padding-top: 60px;
            background-color: #f4f4f4;
            align-items: center;
        }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            border-radius: 0;
        }

        .posts-container {
            width: 95%;
            margin-top: 20px;
        }

        .posts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 15px; /* Add some space below the heading */
        }

        .post {
            background: #575454;
            padding: 15px;
            border-radius: 8px;
            text-align: left;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            color: white;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .post-content {
            flex-grow: 1;
            margin-bottom: 8px;
        }

        .post-image {
            width: 100%;
            height: auto;
            border-radius: 5px;
            margin-top: 8px;
            display: block;
            margin-bottom: 8px;
        }

        .post-caption {
            color: white;
            margin-bottom: 8px;
            white-space: pre-line;
            font-size: 0.9em;
        }

        .post-info {
            font-size: 0.8em;
            color: #ccc;
            margin-bottom: 8px;
        }

        .post-actions-menu {
            position: absolute;
            top: 8px;
            right: 8px;
        }

        .menu-toggle {
            background: none;
            border: none;
            color: #ccc;
            cursor: pointer;
            font-size: 1em;
            padding: 3px;
        }

        .menu-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #444;
            border: 1px solid #666;
            border-radius: 3px;
            padding: 3px 0;
            display: none;
            z-index: 10;
        }

        .menu-dropdown button {
            display: block;
            width: 100%;
            padding: 6px 10px;
            text-align: left;
            border: none;
            background: none;
            color: white;
            cursor: pointer;
            font-size: 0.8em;
        }

        .menu-dropdown button:hover {
            background-color: #555;
        }

        .pagination {
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .pagination a, .pagination span {
            display: inline-block;
            padding: 5px 8px;
            margin-right: 3px;
            text-decoration: none;
            border: 1px solid #ccc;
            border-radius: 3px;
            background-color: white;
            color: #333;
            font-size: 0.8em;
        }

        .pagination a:hover {
            background-color: #f0f0f0;
        }

        .pagination .current {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }

        .pagination .disabled {
            color: #888;
            pointer-events: none;
            background-color: #eee;
            border-color: #eee;
        }

        /* Smaller Modal Styles */
        #editPostModal {
            display: none;
            position: fixed;
            z-index: 100;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 15px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
            position: relative;
        }

        .close-button {
            color: #aaa;
            position: absolute;
            top: 5px;
            right: 10px;
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
        }

        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .edit-form h2 {
            font-size: 1.2em;
            margin-bottom: 8px;
        }

        .edit-form textarea {
            width: 100%;
            padding: 6px;
            margin-bottom: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
            font-size: 0.8em;
            min-height: 60px;
        }

        .edit-form button[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 6px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8em;
        }

        .edit-form button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">AgriShop: Farm Online Website</a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="adminpage.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="adminpostpanel.php"><i class="fas fa-file-alt"></i> Posts</a></li>
                <li><a href="monthly.php"><i class="fas fa-chart-bar"></i> Monthly Stats</a></li>
                <li><a href="profile.php"><img src="<?php echo htmlspecialchars($user_profile_image); ?>" class="profile-pic-nav" alt="Profile"></a></li>
                <li>
                    <a href="#" onclick="confirmLogout()">
                        <i class="fas fa-sign-out-alt fa-lg"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="posts-container">
    <h2 style="text-align: center;">ALL POSTS OF USERS</h2>
    <?php if (!empty($posts_data)): ?>
        <div class="posts-grid">
            <?php foreach ($posts_data as $post): ?>
                <div class="post" data-post-id="<?php echo $post['id']; ?>">
                    <div class="post-content">
                        <?php if (!empty($post['file_path'])): ?>
                            <img src="<?php echo htmlspecialchars($post['file_path']); ?>" alt="<?php echo htmlspecialchars($post['category']); ?>" class="post-image">
                        <?php endif; ?>
                        <p class="post-caption"><?php echo htmlspecialchars($post['description']); ?></p>
                        <div class="post-info">
                            Posted by: <?php echo htmlspecialchars($post['fullname']); ?> on <?php echo htmlspecialchars($post['created_at']); ?>
                        </div>
                    </div>
                    <div class="post-actions-menu">
                        <button class="menu-toggle"><i class="fas fa-ellipsis-v"></i></button>
                        <div class="menu-dropdown">
                            <button onclick="openEditModal(<?php echo $post['id']; ?>, '<?php echo htmlspecialchars(addslashes($post['description'])); ?>')">Edit</button>
                            <button onclick="confirmDelete(<?php echo $post['id']; ?>)">Delete</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p style="text-align: center;">No posts found.</p>
    <?php endif; ?>

    <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>">Back</a>
            <?php else: ?>
                <span class="disabled">Back</span>
            <?php endif; ?>

            <div class="pagination-links">
                <?php
                $show_pages = 3; // Show a limited number of page links
                $start_page = max(1, $page - floor($show_pages / 2));
                $end_page = min($total_pages, $start_page + $show_pages - 1);

                if ($start_page > 1): ?>
                    <span>...</span>
                <?php endif; ?>

                <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($end_page < $total_pages): ?>
                    <span>...</span>
                <?php endif; ?>
            </div>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>">Next</a>
            <?php else: ?>
                <span class="disabled">Next</span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<div id="editPostModal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closeEditModal()">&times;</span>
        <h2 class="edit-form-title">Edit Post</h2>
        <form class="edit-form" id="editPostForm" action="update_post.php" method="post">
            <input type="hidden" name="post_id" id="editPostId">
            <textarea name="description" id="editDescription"></textarea>
            <button type="submit">Save</button>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>

<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = "logout.php";
        }
    }

    function confirmDelete(postId) {
        if (confirm("Are you sure you want to delete this post?")) {
            window.location.href = "delete_posts.php?id=" + postId;
        }
    }

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('menu-toggle')) {
            const dropdown = e.target.nextElementSibling;
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        } else if (!e.target.closest('.post-actions-menu')) {
            document.querySelectorAll('.menu-dropdown').forEach(dropdown => {
                dropdown.style.display = 'none';
            });
        }
    });

    function openEditModal(postId, description) {
        document.getElementById('editPostModal').style.display = "block";
        document.getElementById('editPostId').value = postId;
        document.getElementById('editDescription').value = description;
    }

    function closeEditModal() {
        document.getElementById('editPostModal').style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == document.getElementById('editPostModal')) {
            document.getElementById('editPostModal').style.display = "none";
        }
    }
</script>

</body>
</html>



