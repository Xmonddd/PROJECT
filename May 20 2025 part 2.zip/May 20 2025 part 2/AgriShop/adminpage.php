<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
    header("Location: index.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'] ?? null;

if ($username && (!isset($_SESSION['profile_image']) || !isset($_SESSION['fullname']))) {
    $stmt = $conn->prepare("SELECT fullname, profile_image FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['profile_image'] = $user['profile_image'] ?? 'uploads/default.png';
    }
    $stmt->close();
}

$profile_from_session = $_SESSION['profile_image'] ?? 'uploads/default.png';
$user_profile_image = (strpos($profile_from_session, 'uploads/') === false)
    ? 'uploads/' . $profile_from_session
    : $profile_from_session;

$user_fullname = $_SESSION['fullname'] ?? 'Guest User';

// Pagination settings
$limit = 11;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Fetch total number of users
$total_users_query = "SELECT COUNT(id) AS total FROM users";
$total_result = $conn->query($total_users_query);
if ($total_result) {
    $total_users = $total_result->fetch_assoc()['total'] ?? 0;
    $total_pages = ceil($total_users / $limit);
} else {
    echo "Error fetching total users: " . $conn->error;
    $total_users = 0;
    $total_pages = 0;
}

// Fetch user data and post counts with pagination
$sql = "SELECT
            u.id,
            u.username,
            u.fullname,
            u.email,
            COUNT(mp.id) AS post_count
        FROM users u
        LEFT JOIN mainpost mp ON u.username = mp.username
        GROUP BY u.id, u.username, u.fullname, u.email
        ORDER BY u.fullname
        LIMIT $start, $limit";
$result = $conn->query($sql);
$users_data = [];
if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $name_parts = explode(' ', $row['fullname'], 2);
            $first_name = $name_parts[0] ?? '';
            $last_name = $name_parts[1] ?? '';
            $users_data[] = [
                'id' => $row['id'],
                'username' => $row['username'],
                'first_name' => $first_name,
                'last_name' => $last_name,
                'email' => $row['email'],
                'post_count' => $row['post_count']
            ];
        }
    }
    $result->free_result();
} else {
    echo "Error fetching user data: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop: Farm Online Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <style>
        .admin-container {
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: flex-start; /* Align items to the start vertically */
            padding: 20px;
        }
        .user-table-container {
            width: 80%; /* Adjust width as needed */
        }
        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            margin-bottom: 2rem;
            border: 1px solid #dee2e6; /* Light gray border */
            border-radius: 0.25rem; /* Slightly rounded corners */
            overflow: hidden; /* To contain rounded corners */
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); /* Subtle shadow */
            background-color: #fff;
        }
        .user-table th, .user-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .user-table th {
            background-color: #f2f2f2;
        }
        .pagination {
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center; /* Center pagination */
        }
        .pagination a, .pagination span {
            padding: 5px 10px;
            border: 1px solid #ccc;
            margin-right: 5px;
            text-decoration: none;
            color: #333;
        }
        .pagination .current {
            background-color: #f0f0f0;
            color: #000;
        }
        .pagination .disabled {
            color: #999;
            pointer-events: none;
        }
        .pagination-links {
            display: flex;
        }
        .pagination-links a, .pagination-links span {
            padding: 5px 10px;
            border: 1px solid #ccc;
            margin-right: 5px;
            text-decoration: none;
            color: #333;
        }
        .pagination-links .current {
            background-color: #f0f0f0;
            color: #000;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            align-items: center;
        }
        .action-buttons button {
            background: none;
            border: none;
            padding: 5px;
            cursor: pointer;
        }
        .action-buttons i { /* Style for the icons */
            font-size: 0.8em; /* Adjust this value to make the icons smaller */
        }
        .edit-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 15px;
            border-radius: 8px;
            width: 400px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            font-family: sans-serif;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 10px;
            margin-bottom: 15px;
            border-bottom: 1px solid #ddd;
        }
        .modal-header h2 {
            margin: 0;
            font-size: 1.2em;
            color: #333;
        }
        .close-button {
            color: #aaa;
            font-size: 1.5em;
            font-weight: bold;
            cursor: pointer;
            border: none;
            background: none;
            padding: 0;
            opacity: 0.6;
        }
        .close-button:hover,
        .close-button:focus {
            color: #333;
            text-decoration: none;
            opacity: 1;
        }
        .modal-body label {
            display: block;
            margin-bottom: 5px;
            font-size: 0.9em;
            color: #555;
        }
        .modal-body input[type=text],
        .modal-body input[type=email] {
            width: calc(100% - 12px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 0.9em;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            padding-top: 15px;
            margin-top: 15px;
            border-top: 1px solid #eee;
            gap: 10px;
        }
        .save-button,
        .modal-footer button {
            background-color: #1877f2;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }
        .save-button:hover,
        .modal-footer button:hover {
            background-color: #166fe6;
        }
        .modal-footer button[onclick="closeEditModal()"] {
            background-color: #e4e6eb;
            color: #333;
        }
        .modal-footer button[onclick="closeEditModal()"]:hover {
            background-color: #d8dadf;
        }
        .save-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .save-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">AgriShop: Farm Online Website</a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="adminpage.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="adminpostpanel.php"><i class="fas fa-file-alt"></i> Posts</a></li>
                <li><a href="monthly.php"><i class="fas fa-chart-bar"></i> Monthly Stats</a></li>
                <li><a href="profile.php"><img src="<?php echo htmlspecialchars($user_profile_image); ?>" class="profile-pic-nav" alt="Profile"></a></li>
                <li>
                    <a href="#" onclick="confirmLogout()">
                        <i class="fas fa-sign-out-alt fa-lg"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="admin-container">
    <div class="user-table-container">
        <h2>USERS</h2>
        <table class="user-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Posts</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($users_data)): ?>
                    <?php foreach ($users_data as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['first_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['post_count']); ?></td>
                            <td class="action-buttons">
                                <button title="Edit" onclick="openEditModal(<?php echo htmlspecialchars($user['id']); ?>, '<?php echo htmlspecialchars($user['username']); ?>', '<?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>', '<?php echo htmlspecialchars($user['email']); ?>')">
                                    <i class="fas fa-edit" style="font-size: 0.8em; color: black;"></i>
                                </button>
                                <button title="Delete" onclick="confirmDelete(<?php echo htmlspecialchars($user['id']); ?>)">
                                    <i class="fas fa-trash-alt" style="color: red; font-size: 0.8em;"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5">No users found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>">Back</a>
                <?php else: ?>
                    <span class="disabled">Back</span>
                <?php endif; ?>

                <div class="pagination-links">
                    <?php
                    $show_pages = 5;
                    $start_page = max(1, $page - floor($show_pages / 2));
                    $end_page = min($total_pages, $start_page + $show_pages - 1);

                    if ($start_page > 1): ?>
                        <span>...</span>
                    <?php endif; ?>

                    <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if ($end_page < $total_pages): ?>
                        <span>...</span>
                    <?php endif; ?>
                </div>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>">Next</a>
                <?php else: ?>
                    <span class="disabled">Next</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div id="editModal" class="edit-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Edit User</h2>
            <span class="close-button" onclick="closeEditModal()">&times;</span>
        </div>
        <div class="modal-body">
            <input type="hidden" id="editUserId">
            <label for="editUsername">Username:</label>
            <input type="text" id="editUsername" readonly>
            <label for="editFirstName">First Name:</label>
            <input type="text" id="editFirstName">
            <label for="editLastName">Last Name:</label>
            <input type="text" id="editLastName">
            <label for="editEmail">Email:</label>
            <input type="email" id="editEmail">
        </div>
        <div class="modal-footer">
            <button class="save-button" onclick="saveUserChanges()">Save Changes</button>
            <button onclick="closeEditModal()">Cancel</button>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>

<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = "logout.php";
        }
    }

    function confirmDelete(userId) {
        if (confirm("Are you sure you want to delete this user?")) {
            window.location.href = "delete_user.php?id=" + userId; // Create this file
        }
    }

    let currentEditUserId;

    function openEditModal(userId, username, fullname, email) {
        currentEditUserId = userId;
        const nameParts = fullname.split(' ');
        const firstName = nameParts[0] || '';
        const lastName = nameParts.slice(1).join(' ') || '';

        document.getElementById('editUserId').value = userId;
        document.getElementById('editUsername').value = username;
        document.getElementById('editFirstName').value = firstName;
        document.getElementById('editLastName').value = lastName;
        document.getElementById('editEmail').value = email;
        document.getElementById('editModal').style.display = "block";
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = "none";
    }

    function saveUserChanges() {
        const userId = document.getElementById('editUserId').value;
        const firstName = document.getElementById('editFirstName').value;
        const lastName = document.getElementById('editLastName').value;
        const email = document.getElementById('editEmail').value;

        // Send AJAX request to update user data
        $.ajax({
            url: 'edit_user.php', // Create this file
            type: 'POST',
            data: {
                id: userId,
                first_name: firstName,
                last_name: lastName,
                email: email
            },
            success: function(response) {
                if (response === 'success') {
                    alert('User information updated successfully!');
                    location.reload(); // Reload the page to see changes
                } else {
                    alert('Error updating user information.');
                }
                closeEditModal();
            },
            error: function(xhr, status, error) {
                console.error(error);
                alert('An error occurred while updating user.');
            }
        });
    }

    // Close the modal if the user clicks outside of it
    window.onclick = function(event) {
        const modal = document.getElementById('editModal');
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

</body>
</html>