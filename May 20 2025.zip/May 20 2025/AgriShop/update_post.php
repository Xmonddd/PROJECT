<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['post_id']) && is_numeric($_POST['post_id']) && isset($_POST['description'])) {
    $postIdToUpdate = $_POST['post_id'];
    $newDescription = $_POST['description'];

    $conn = new mysqli("localhost", "root", "", "agrishop");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE posts SET description = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error); // This line is crucial
    }

    $stmt->bind_param("si", $newDescription, $postIdToUpdate);

    if ($stmt->execute()) {
        header("Location: adminpostpanel.php");
        exit();
    } else {
        echo "Error updating post: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    exit();
} else {
    header("Location: adminpostpanel.php");
    exit();
}
?>