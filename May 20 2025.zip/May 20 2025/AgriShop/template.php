<?php

include("functions.php");

// PHP goes here!

?>

    <!-- Header section  -->
<?php include("header.php") ?>

    <!-- Main section  -->
    <div class="container">
        <h1>Welcome</h1>
    </div>

    <!-- Footer section  -->
<?php include("footer.php") ?>