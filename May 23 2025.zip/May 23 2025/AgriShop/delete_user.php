<?php
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    session_start();
    if (!isset($_SESSION['username']) || $_SESSION['is_admin'] != true) {
        header("Location: index.php");
        exit();
    }

    $conn = new mysqli("localhost", "root", "", "agrishop");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $user_id_to_delete = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id_to_delete);

    if ($stmt->execute()) {
        header("Location: adminpage.php?delete_success=true");
    } else {
        header("Location: adminpage.php?delete_error=true");
    }

    $stmt->close();
    $conn->close();
    exit();
} else {
    header("Location: adminpage.php");
    exit();
}
?>