

<?php

session_start();
if (isset($_SESSION['username'])) {
    header("Location: buying.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    
    <style>
    body {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 100vh;
        margin: 0;
        padding: 0;
        background-color: white;
        font-family: Arial, sans-serif;
    }

    .left-section {
        flex: 1;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        padding-left: 20px;
    }

    .mainimage {
        max-width: 90%;
        height: auto;
    }

    .custom-container {
        flex: 1;
        max-width: 450px;
        padding: 30px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.3);
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        margin-right: 200px;
        position: relative;
    }

    .logo {
        position: absolute;
        top: -280px;
        width: 280px;
        height: auto;
    }

    .custom-container h2 {
        font-size: 28px;
        margin-bottom: 10px;
    }

    .custom-container h3 {
        font-size: 20px;
        color: #555;
        margin-bottom: 25px;
    }

    .form-control {
        width: 100%;
        margin-bottom: 15px;
        padding: 14px 12px;
        font-size: 17px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }

    .password-container {
        position: relative;
        width: 100%;
    }

    .password-container .toggle-password {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: #888;
        font-size: 18px;
    }

    .btn-primary {
        background-color: #007BFF;
        border: none;
        color: white;
        padding: 14px;
        width: 100%;
        font-size: 18px;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 10px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    .forgot-password {
        margin-top: 12px;
        font-size: 14px;
    }

    .forgot-password a {
        color: #007BFF;
        text-decoration: none;
    }

    .forgot-password a:hover {
        text-decoration: underline;
    }

    .footer {
        text-align: center;
        padding: 10px;
        background-color: white;
        border-top: 1px solid #ddd;
        position: fixed;
        bottom: 0;
        width: 100%;
    }

    .recaptcha-wrapper {
    width: 100%;
    display: flex;
    justify-content: center;
    margin: 20px 0;
}

.recaptcha-inner {
    transform: scale(1.15); /* Increase size slightly */
    transform-origin: top center;
}


     /* Responsive Design */
     @media (max-width: 768px) {
        body {
            flex-direction: column;
            height: auto;
        }

        .left-section {
            order: 2;
            padding: 10px;
        }

        .custom-container {
            order: 1;
            margin: 20px 0;
        }

        .logo {
            top: -220px;
            width: 180px;
        }
    }

    @media (max-width: 480px) {
        .custom-container {
            padding: 20px;
        }

        .custom-container h2 {
            font-size: 24px;
        }

        .custom-container h3 {
            font-size: 18px;
        }

        .form-control {
            font-size: 16px;
            padding: 12px;
        }

        .btn-primary {
            font-size: 16px;
            padding: 12px;
        }
    }
    @media (max-width: 768px) {
    .left-section {
        order: 2;
        padding: 10px;
    }

    .mainimage {
        width: 80%;
        max-width: 300px;
        margin: 0 auto;
    }
}

@media (max-width: 480px) {
    .mainimage {
        width: 90%;
        max-width: 250px;
    }
}
@media (max-width: 768px) {
    .recaptcha-inner {
        transform: scale(0.9);
    }
}

@media (max-width: 480px) {
    .recaptcha-inner {
        transform: scale(0.8);
    }
}


</style>
    
</head>
<body>

<div class="left-section">
    <img src="image/homepic.png" alt="" class="mainimage">
</div>

<div class="custom-container">

    <h2>AgriShop: Farmer Online</h2>
    <h3>Selling Web Application</h3>
    <form action="login.php" method="POST" style="width: 100%; max-width: 450px;">
    <input type="text" name="username" placeholder="Username" required 
           class="form-control" 
           style="padding: 16px; font-size: 18px; margin-bottom: 15px;">

    <!-- Password field with toggle visibility -->
    <!-- Password Input with Toggle -->
    <div class="password-container" style="
    position: relative;
    width: 100%;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);  /* Shadow added */
    border-radius: 5px;
    background-color: #fff;
">
    <input type="password" name="password" placeholder="Password" required 
           class="form-control" id="password"
           style="padding: 16px 50px 16px 16px; font-size: 18px; width: 100%; border: none; outline: none; border-radius: 5px;">
    
    <span class="glyphicon glyphicon-eye-open toggle-password" id="toggle-password"
          style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); font-size: 20px; color: #888; cursor: pointer;">
    </span>
</div>

<div class="forgot-password" style="width: 100%; text-align: left; margin-bottom: 20px;">
    <a href="forgot-password.php" style="font-size: 14px; color: #007BFF; text-decoration: none;">
        Forgot Password?
    </a>
</div>

<!-- Google reCAPTCHA (Scaled & Centered Like Login Button) -->
<div class="recaptcha-wrapper">
    <div class="g-recaptcha recaptcha-inner"
         data-sitekey="6LczkDMrAAAAAP8xXG6xfiscM_zx6FnX3Lr2zi6Z">
    </div>
</div>



    <button type="submit" class="btn btn-primary btn-block" 
            style="padding: 14px; font-size: 18px; width: 100%;">
        Login
    </button>
</form>

    
    

<div class="signup-link" style="margin-top: 15px;">
    <a href="register.php">Signup here</a>
</div>



</div>


<footer class="footer">
    <p>&copy; 2025 AgriShop</p>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
    // Toggle password visibility
    const togglePassword = document.getElementById('toggle-password');
    const passwordField = document.getElementById('password');

    togglePassword.addEventListener('click', function () {
        // Toggle the type attribute
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);

        // Toggle the eye icon class
        this.classList.toggle('glyphicon-eye-open');
        this.classList.toggle('glyphicon-eye-close');
    });
</script>
</body>
</html>