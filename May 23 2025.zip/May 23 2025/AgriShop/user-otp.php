<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: controllerUserData.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Code Verification</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .form-container {
            margin-top: 100px;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #343a40;
        }
        .form-control {
            border-radius: 8px;
        }
        .btn-custom {
            width: 100%;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 10px;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .alert {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="col-md-6 col-lg-5 form-container">
            <form action="user-otp.php" method="POST" autocomplete="off">
                <h2 class="text-center mb-3">Code Verification</h2>
                <?php 
                if(isset($_SESSION['info'])): ?>
                    <div class="alert alert-success text-center">
                        <?php echo $_SESSION['info']; ?>
                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger text-center">
                        <?php foreach($errors as $showerror){
                            echo $showerror;
                        } ?>
                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <input class="form-control" type="number" name="otp" placeholder="Enter verification code" required>
                </div>
                <div class="form-group">
                    <button class="btn btn-custom" type="submit" name="check-reset-otp">Submit</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
