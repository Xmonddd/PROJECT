<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

// Fetch user profile information
$sql_user = "SELECT fullname, profile_image FROM users WHERE username = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("s", $username);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user_data = $result_user->fetch_assoc();

$fullname = $user_data['fullname'];
$profile_image = !empty($user_data['profile_image']) ? htmlspecialchars($user_data['profile_image']) : 'uploads/default.png';

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop: Farm Online Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
      
        .welcome-banner {
          background: gray;
            color: #fff;
            padding: 32px 18px 22px 18px;
            border-radius: 10px;
            text-align: center;
            margin: 30px auto 10px auto;
            max-width: 1050px;
            box-shadow: 0 2px 12px rgba(76,175,80,0.15);
        }
        .welcome-banner h1 {
            margin-top: 0;
            font-size: 2.2em;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .welcome-banner p {
            font-size: 1.15em;
            margin: 12px 0 0 0;
            color: #e6ffe6;
        }
        .container1 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    padding: 0 15px;
}
.card {
    width: 100%;
    max-width: 300px;
    margin: auto;
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.45); /* stronger and deeper shadow */
}

        .card:hover {
            transform: translateY(-5px) scale(1.03);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.45); /* very strong shadow */ /* stronger and deeper shadow */
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }
        .card h3 {
            margin: 10px 0 5px;
            font-size: 16px;
        }
        .card .price {
            margin: 0;
            font-weight: bold;
            color: #2a8b2a;
        }
        .profile-pic-nav {
            width:32px;
            height:32px;
            object-fit:cover;
            border-radius:50%;
            margin-right: 7px;
            border:2px solid #eee;
        }
        
        .welcome-banner {
  position: relative;
  width: 100%;
  height: 420px;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  display: flex;
  align-items: flex-end;
  justify-content: flex-start;
  border-radius: 16px;
  overflow: hidden;
}

.banner-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(51, 51, 51, 0.6); /* #333 with 60% opacity */

  color: #fff;
  padding: 46px 60px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  border-radius: 16px;
}

.banner-overlay h1 {
  font-size: 3.2rem;
  font-weight: bold;
  margin-bottom: 20px;
}

.banner-overlay p {
  font-size: 1.2rem;
  max-width: 800px;
  margin-bottom: 30px;
  line-height: 1.6;
}

.cta-btn {
  display: inline-block;
  padding: 14px 32px;
  background-color: #00e676;
  color: #134f13;
  font-weight: bold;
  border-radius: 50px;
  font-size: 1.1rem;
  text-decoration: none;
  transition: all 0.3s ease;
  
  
}

.cta-btn:hover {
  background-color: #13c759;
  color: white;
}

@media (max-width: 900px) {
      .welcome-banner {
        height: 300px;
      }
    }
    @media (max-width: 600px) {
      .welcome-banner {
        height: 180px;
      }
    }
    .welcome-banner p {
      font-size: 1.15rem;
      margin-bottom: 24px;
      line-height: 1.7;
    }
    .welcome-container {
  font-family: Helvetica, Arial, sans-serif;
  padding: 20px;
  line-height: 1.6;
}
.welcome-container h1 {
  font-size: 5rem; /* scalable */
  text-align: center;
  margin-bottom: 20px;
  font-family: Arial, Helvetica, sans-serif;
}

.welcome-container p {
  font-size: 2rem;
  text-align: center;
  padding: 0 15px;
  max-width: 100%;
  line-height: 1.6;
  font-family: Arial, Helvetica, sans-serif;
}

@media (max-width: 768px) {
  .banner-overlay h1 {
    font-size: 2rem;
    text-align: center;
  }
  .banner-overlay p {
    font-size: 1rem;
    text-align: center;
  }
  .cta-btn {
    display: block;
    margin: 0 auto;
    font-size: 1rem;
    padding: 12px 24px;
  }
}
@media (max-width: 768px) {
  .welcome-container h1 {
    font-size: 1.8rem;
  }

  .welcome-container p {
    font-size: 1rem;
    padding: 0 10px;
  }
}

@media (max-width: 480px) {
  .welcome-container h1 {
    font-size: 1.4rem;
  }

  .welcome-container p {
    font-size: 0.95rem;
  }
}



    </style>
</head>
<body>



<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">AgriShop: Farm Online Website</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-collapse">
  <ul class="nav navbar-nav navbar-right">
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'srp.php' ? 'active' : ''; ?>">
                <a href="srp.php"><i class="fas fa-home"></i> HOME</a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'buying.php' ? 'active' : ''; ?>">
                <a href="buying.php"><i class="fas fa-shopping-cart"></i> PURCHASE</a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'selling.php' ? 'active' : ''; ?>">
                <a href="selling.php"><i class="fas fa-tag"></i> SELL</a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'mainhome.php' ? 'active' : ''; ?>">
                <a href="mainhome.php"><i class="fas fa-home"></i> TRANSACT</a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'message.php' ? 'active' : ''; ?>">
                <a href="message.php"><i class="fas fa-envelope fa-2x"></i></a>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <img src="<?php echo $profile_image; ?>" alt="Profile" class="profile-pic-nav"> <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<!-- Welcome Banner -->
<!-- Banner Section -->

       
    <div class="welcome-container">
    <h1>Welcome to AgriShop, <?php echo htmlspecialchars($fullname); ?>!</h1>
    <p>
        AgriShop is your trusted online marketplace connecting local farmers and buyers.<br>
        Our mission is to make buying and selling fresh produce easy, transparent, and accessible for everyone.<br>
        Discover real-time prices, purchase quality farm products, or offer your own harvest all in one convenient platform.<br>
        Enjoy seamless transactions, direct-from-farm freshness, and support the local agricultural community.<br>
        Join us as we cultivate a better, greener future together!
    </p>
</div>

        
    </div>
</div>
<h2 style="text-align:center;margin:30px 0 20px;">Suggested Retail Price (SRP)</h2>
<div class="container1">
  <?php
    $products = [
      ['name' => 'Rice', 'image' => 'srp/rice.jpg', 'weight' => '1kg', 'min_price' => 45.00, 'max_price' => 55.00],
      ['name' => 'Corn', 'image' => 'srp/corn.jpg', 'weight' => 'kg', 'min_price' => 30.00, 'max_price' => 40.00],
      ['name' => 'Mango', 'image' => 'srp/mango.jpeg', 'weight' => 'kg', 'min_price' => 80.00, 'max_price' => 120.00],
      ['name' => 'Tomato', 'image' => 'srp/tomato.jpg', 'weight' => '1kg', 'min_price' => 60.00, 'max_price' => 80.00],
      ['name' => 'Onion', 'image' => 'srp/onion.jpg', 'weight' => 'kg', 'min_price' => 70.00, 'max_price' => 90.00],
      ['name' => 'Sweet Potato', 'image' => 'srp/sweet_potato.jpg', 'weight' => 'kg', 'min_price' => 25.00, 'max_price' => 35.00],
      ['name' => 'Cabbage', 'image' => 'srp/cabbage.jpg', 'weight' => 'kg', 'min_price' => 40.00, 'max_price' => 50.00],
      ['name' => 'Carrot', 'image' => 'srp/carrot.jpg', 'weight' => 'kg', 'min_price' => 55.00, 'max_price' => 65.00],
      ['name' => 'Banana (Saba)', 'image' => 'srp/banana.jpg', 'weight' => 'kg', 'min_price' => 20.00, 'max_price' => 30.00],
      ['name' => 'Eggplant', 'image' => 'srp/eggplant.jpg', 'weight' => 'kg', 'min_price' => 35.00, 'max_price' => 45.00],
      ['name' => 'Green Beans', 'image' => 'srp/green_beans.jpg', 'weight' => 'kg', 'min_price' => 60.00, 'max_price' => 75.00],
      ['name' => 'Watermelon', 'image' => 'srp/watermelon.jpg', 'weight' => 'kg', 'min_price' => 30.00, 'max_price' => 40.00],
      ['name' => 'Pineapple', 'image' => 'srp/pineapple.jpg', 'weight' => 'kg', 'min_price' => 45.00, 'max_price' => 55.00],
      ['name' => 'Papaya', 'image' => 'srp/papaya.jpg', 'weight' => 'kg', 'min_price' => 35.00, 'max_price' => 45.00],
      ['name' => 'Ginger', 'image' => 'srp/ginger.jpg', 'weight' => 'kg', 'min_price' => 120.00, 'max_price' => 150.00]
    ];

    foreach ($products as $product) {
      echo '<div class="card">';
      echo '<img src="' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['name']) . '">';
      echo '<h3>' . htmlspecialchars($product['name']) . ' <small>' . htmlspecialchars($product['weight']) . '</small></h3>';
      echo '<p class="price">₱ ' . number_format($product['min_price'], 2) . ' – ₱ ' . number_format($product['max_price'], 2) . ' / kilogram</p>';
      echo '</div>';
    }
  ?>
</div>
<script>
  $(document).on('click', '.navbar-collapse.in a', function(e) {
    if ($(e.target).is('a') && !$(e.target).hasClass('dropdown-toggle')) {
      $('.navbar-collapse').collapse('hide');
    }
  });
</script>


</body>
</html>