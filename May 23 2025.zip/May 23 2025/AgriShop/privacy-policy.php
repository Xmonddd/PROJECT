<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Privacy Policy</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            color: #333;
        }

        .policy-container {
            max-width: 900px;
            margin: 60px auto;
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        }

        h1 {
            text-align: center;
            color: #007BFF;
            margin-bottom: 30px;
        }

        h3 {
            color: #444;
            margin-top: 30px;
        }

        ul {
            margin-left: 20px;
            padding-left: 10px;
        }

        li {
            margin-bottom: 10px;
        }

        p {
            margin-bottom: 20px;
            font-size: 16px;
        }

        .back-link {
            display: inline-block;
            margin-top: 40px;
            text-align: center;
            text-decoration: none;
            color: #007BFF;
            border: 1px solid #007BFF;
            padding: 10px 20px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            background-color: #007BFF;
            color: white;
        }

        footer {
            text-align: center;
            margin-top: 60px;
            font-size: 13px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="policy-container">
        <h1>Privacy Policy</h1>
        <p>We respect your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, and protect your data during the registration process.</p>

        <h3>What Data We Collect</h3>
        <ul>
            <li>Full Name (First and Last Name)</li>
            <li>Email Address (Gmail only)</li>
            <li>Username</li>
            <li>Password (stored securely using hashing)</li>
            <li>Profile Picture (optional)</li>
        </ul>

        <h3>How We Use Your Information</h3>
        <p>Your data is used strictly for account creation, login authentication, and profile management within our system. We do not share your information with any third parties without your consent.</p>

        <h3>Security Measures</h3>
        <p>Passwords are hashed before storing in the database to enhance security. We follow best practices to ensure your information is stored and managed safely.</p>

        <h3>Your Consent</h3>
        <p>By using our registration form, you consent to our collection and use of your personal information as outlined in this Privacy Policy.</p>

        <a class="back-link" href="register.php">← Back to Registration</a>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> YourSite. All rights reserved.
    </footer>
</body>
</html>
