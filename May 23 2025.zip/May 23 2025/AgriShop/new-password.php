<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: login1.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create a New Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            background: #eef2f7;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .form-container {
            margin-top: 100px;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #343a40;
            margin-bottom: 20px;
        }
        .form-control {
            border-radius: 8px;
        }
        .btn-custom {
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 10px;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
        .alert {
            margin-top: 10px;
        }
        .input-group-text {
            background: white;
            border-left: 0;
            cursor: pointer;
        }
        .input-group .form-control {
            border-right: 0;
        }
        .password-rules {
            font-size: 0.875rem;
            color: #6c757d;
        }
        .password-rules.valid {
            color: #28a745;
        }
        .password-rules.invalid {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="col-md-6 col-lg-5 form-container">
            <form action="new-password.php" method="POST" autocomplete="off">
                <h2 class="text-center">Create a New Password</h2>

                <?php if(isset($_SESSION['info'])): ?>
                    <div class="alert alert-success text-center">
                        <?php echo $_SESSION['info']; ?>
                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger text-center">
                        <?php foreach($errors as $showerror){ echo $showerror; } ?>
                    </div>
                <?php endif; ?>

                <!-- New Password Field -->
                <div class="form-group">
                    <div class="input-group">
                        <input id="password" class="form-control" type="password" name="password" placeholder="Create new password" required
                               pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}"
                               title="At least 8 characters, with uppercase, lowercase, number, and special character.">
                        <div class="input-group-append">
                            <span class="input-group-text" onclick="togglePassword('password', this)">
                                <i class="bi bi-eye-slash"></i>
                            </span>
                        </div>
                    </div>
                    <div class="password-rules" id="passwordHelp">
                        • At least 8 characters<br>
                        • One uppercase letter<br>
                        • One lowercase letter<br>
                        • One number<br>
                        • One special character
                    </div>
                </div>

                <!-- Confirm Password Field -->
                <!-- Confirm Password Field -->
<div class="form-group">
    <div class="input-group">
        <input id="cpassword" class="form-control" type="password" name="cpassword" placeholder="Confirm your password" required>
        <div class="input-group-append">
            <span class="input-group-text" onclick="togglePassword('cpassword', this)">
                <i class="bi bi-eye-slash"></i>
            </span>
        </div>
    </div>
    <small id="confirmError" class="form-text text-danger" style="display: none;">Passwords do not match.</small>
</div>


                <div class="form-group">
                    <button class="btn btn-custom btn-block" type="submit" name="change-password">Change</button>
                </div>
            </form>
        </div>
    </div>
    <script>
    const confirmInput = document.getElementById("cpassword");
    const confirmError = document.getElementById("confirmError");
    const form = document.querySelector("form");

    // Check on input
    confirmInput.addEventListener("input", () => {
        if (confirmInput.value !== passwordInput.value) {
            confirmError.style.display = "block";
        } else {
            confirmError.style.display = "none";
        }
    });

    // Prevent form submission if passwords don't match
    form.addEventListener("submit", function(e) {
        if (confirmInput.value !== passwordInput.value) {
            confirmError.style.display = "block";
            e.preventDefault(); // Stop form submission
        }
    });
</script>


    <script>
        function togglePassword(fieldId, iconElement) {
            const input = document.getElementById(fieldId);
            const icon = iconElement.querySelector('i');

            if (input.type === "password") {
                input.type = "text";
                icon.classList.remove("bi-eye-slash");
                icon.classList.add("bi-eye");
            } else {
                input.type = "password";
                icon.classList.remove("bi-eye");
                icon.classList.add("bi-eye-slash");
            }
        }

        // Optional: live password strength indicator (basic)
        const passwordInput = document.getElementById("password");
        const helpText = document.getElementById("passwordHelp");

        passwordInput.addEventListener("input", () => {
            const val = passwordInput.value;
            const regex = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}/;
            if (regex.test(val)) {
                helpText.classList.remove("invalid");
                helpText.classList.add("valid");
            } else {
                helpText.classList.remove("valid");
                helpText.classList.add("invalid");
            }
        });
    </script>
</body>
</html>
