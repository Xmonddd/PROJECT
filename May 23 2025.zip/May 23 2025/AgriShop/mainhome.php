<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

include 'post.php';

$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$username = $_SESSION['username'] ?? null;

if ($username && (!isset($_SESSION['profile_image']) || !isset($_SESSION['fullname']))) {
    $stmt = $conn->prepare("SELECT fullname, profile_image FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['profile_image'] = $user['profile_image'] ?? 'uploads/default.png';
    }
    $stmt->close();
}

$user_fullname = $_SESSION['fullname'] ?? 'Guest User';
$profile_from_session = $_SESSION['profile_image'] ?? 'uploads/default.png';
$user_profile_image = (strpos($profile_from_session, 'uploads/') === false)
    ? 'uploads/' . $profile_from_session
    : $profile_from_session;

$srp_items_per_page = 15;
$srp_current_page = isset($_GET['srp_page']) ? intval($_GET['srp_page']) : 1;
$srp_offset = ($srp_current_page - 1) * $srp_items_per_page;

$sql_total_srp = "SELECT COUNT(*) AS total FROM srp_prices";
$result_total_srp = $conn->query($sql_total_srp);
$total_srp_rows = $result_total_srp->fetch_assoc()['total'];
$total_srp_pages = ceil($total_srp_rows / $srp_items_per_page);

$sql_srp = "SELECT crop_name, min_price, max_price FROM srp_prices LIMIT $srp_offset, $srp_items_per_page";
$result_srp = $conn->query($sql_srp);
$srp_prices = [];
if ($result_srp->num_rows > 0) {
    while ($row = $result_srp->fetch_assoc()) {
        $srp_prices[] = $row;
    }
}

if (isset($_POST['session_post_description']) && isset($_FILES['session_post_image'])) {
    $description = $_POST['session_post_description'];
    $image = $_FILES['session_post_image'];
    $username = $_SESSION['username'] ?? null;

    $upload_dir = 'uploads/';
    $image_name = basename($image['name']);
    $upload_file = $upload_dir . $image_name;

    if (move_uploaded_file($image['tmp_name'], $upload_file)) {
        $sql_insert_post = "INSERT INTO mainpost (username, description, file_path, created_at)
                                            VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql_insert_post);
        $stmt->bind_param("sss", $username, $description, $upload_file);

        if ($stmt->execute()) {
            header("Location: mainhome.php");
            exit();
        } else {
            echo "Error saving post to database: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error uploading image.";
    }
}

// Handle post deletion
if (isset($_POST['delete_post_id'])) {
    $delete_post_id = $_POST['delete_post_id'];
    $sql_delete = "DELETE FROM mainpost WHERE id = ? AND username = ?";
    $stmt_delete = $conn->prepare($sql_delete);

    if ($stmt_delete === false) {
        echo "Error preparing SQL: " . $conn->error;
        exit();
    }

    $stmt_delete->bind_param("is", $delete_post_id, $username);
    if ($stmt_delete->execute()) {
        header("Location: mainhome.php"); // Reload the page to reflect changes
        exit();
    } else {
        echo "Error deleting post: " . $stmt_delete->error;
    }
    $stmt_delete->close();
}

// Handle post editing
if (isset($_POST['edit_post_id']) && isset($_POST['edit_description'])) {
    $edit_post_id = $_POST['edit_post_id'];
    $edit_description = $_POST['edit_description'];
    $sql_update = "UPDATE mainpost SET description = ? WHERE id = ? AND username = ?";
    $stmt_update = $conn->prepare($sql_update);

    if ($stmt_update === false) {
        echo "Error preparing update SQL: " . $conn->error;
        exit();
    }

    $stmt_update->bind_param("sis", $edit_description, $edit_post_id, $username);
    if ($stmt_update->execute()) {
        header("Location: mainhome.php"); // Reload to see changes
        exit();
    } else {
        echo "Error updating post: " . $stmt_update->error;
    }
    $stmt_update->close();
}

$sql_fetch_posts = "SELECT mp.*, u.fullname, u.profile_image
                                     FROM mainpost mp
                                     INNER JOIN users u ON mp.username = u.username
                                     ORDER BY mp.created_at DESC";
$result_posts = $conn->query($sql_fetch_posts);
$main_posts = [];
if ($result_posts->num_rows > 0) {
    while ($row = $result_posts->fetch_assoc()) {
        $main_posts[] = $row;
    }
}

$user_fullname = isset($_SESSION['fullname']) ? $_SESSION['fullname'] : 'Guest User';
$user_profile_image = isset($_SESSION['profile_image']) ? $_SESSION['profile_image'] : 'uploads/default.png';
$username = isset($_SESSION['username']) ? $_SESSION['username'] : null;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AgriShop: Farm Online Website</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <link rel="stylesheet" href="css/stylemainhome.css">
   
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="mainhome.php" class="navbar-brand">AgriShop: Farm Online Website</a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
  <ul class="nav navbar-nav navbar-right">
    <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'srp.php' ? 'active' : ''; ?>">
        <a href="srp.php"><i class="fas fa-home"></i> HOME</a>
    </li>
    <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'buying.php' ? 'active' : ''; ?>">
        <a href="buying.php"><i class="fas fa-shopping-cart"></i> PURCHASE</a>
    </li>
    <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'selling.php' ? 'active' : ''; ?>">
        <a href="selling.php"><i class="fas fa-tag"></i> SELL</a>
    </li>
    <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'mainhome.php' ? 'active' : ''; ?>">
        <a href="mainhome.php"><i class="fas fa-home"></i> TRANSACT</a>
    </li>
    <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'message.php' ? 'active' : ''; ?>">
        <a href="message.php"><i class="fas fa-envelope fa-2x"></i></a>
    </li>
    <li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
    <img src="<?php echo htmlspecialchars($user_profile_image); ?>" alt="Profile" class="profile-pic-nav">
    <span class="caret"></span>
</a>
        <ul class="dropdown-menu">
            <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </li>
</ul>
        </div>
    </div>
</nav>



    <!-- post -->
    <div class="main-content">
        <div class="feed-container">
            <div class="post-creation-container" data-toggle="modal" data-target="#postModal">
                <div class="profile-info-inline">
                    <img src="<?php echo htmlspecialchars($user_profile_image); ?>" alt="Profile Picture">
                </div>
                <div class="post-placeholder">Click to post your success transaction</div>
            </div>

            <div class="post-display-container">
                <div class="posts">
                    <?php if (!empty($main_posts)): ?>
                        <?php foreach ($main_posts as $post): ?>
                            <div class="post">
                                <div class="post-header">
                                    <div class="post-header-left">
                                        <img src="<?php echo htmlspecialchars($post['profile_image']); ?>" alt="User Profile">
                                        <span class="username"><?php echo htmlspecialchars($post['fullname']); ?></span>
                                    </div>
                                    <span class="time"><?php echo date('F j, Y, g:i a', strtotime($post['created_at'])); ?></span>
                                </div>
                                <div class="post-content"><?php echo htmlspecialchars($post['description']); ?></div>
                                <?php if (!empty($post['file_path'])): ?>
                                    <img src="<?php echo htmlspecialchars($post['file_path']); ?>" class="post-image">
                                <?php endif; ?>
                                <?php if ($post['username'] === $username): ?>
                                    <div class="post-options">
                                        <button class="post-options-btn" onclick="togglePostOptions(this)">
                                            <i class="fas fa-ellipsis-h"></i>
                                        </button>
                                        <div class="post-options-dropdown">
                                            <button onclick="openEditModal(<?php echo $post['id']; ?>, '<?php echo htmlspecialchars(addslashes($post['description'])); ?>')">Edit</button>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="delete_post_id" value="<?php echo $post['id']; ?>">
                                                <button type="submit" onclick="return confirm('Are you sure you want to delete this post?')">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="color: #777;">No posts yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!--edit in 3dot-->
    <div id="editModal" class="edit-modal">
        <div class="edit-modal-content">
            <span class="edit-modal-close" onclick="closeEditModal()">&times;</span>
            <h3>Edit Post</h3>
            <form method="POST">
                <input type="hidden" name="edit_post_id" id="edit_post_id">
                <textarea id="edit_description" name="edit_description" rows="5" required></textarea>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
        </div>
    </div>

    <!-- create post modal -->
    <div class="modal fade" id="postModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Create a Post</h4>
                </div>
                <div class="modal-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="profile-info">
                            <img src="<?php echo htmlspecialchars($user_profile_image); ?>" alt="ProfilePicture">
                            <strong><?php echo htmlspecialchars($user_fullname); ?></strong>
                        </div>
                        <textarea name="session_post_description" placeholder="What's on your mind?" required></textarea>
                        <input type="file" name="session_post_image" accept="image  " required>
                        <button type="submit" class="btn btn-primary">Post</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script>
    function togglePostOptions(button) {
        var dropdown = button.nextElementSibling;
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    window.onclick = function(event) {
        if (!event.target.matches('.post-options-btn')) {
            var dropdowns = document.getElementsByClassName("post-options-dropdown");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.style.display === 'block') {
                    openDropdown.style.display = 'none';
                }
            }
        }
        // Close edit modal if clicked outside
        var modal = document.getElementById("editModal");
        if (event.target == modal) {
            closeEditModal();
        }
    }

    function openEditModal(postId, description) {
        document.getElementById('edit_post_id').value = postId;
        document.getElementById('edit_description').value = description;
        document.getElementById('editModal').style.display = "block";
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = "none";
    }

    $(document).ready(function(){
        // No specific JavaScript needed for the main modal
    });
</script>
<script>
  $(document).on('click', '.navbar-collapse.in a', function(e) {
    if ($(e.target).is('a') && !$(e.target).hasClass('dropdown-toggle')) {
      $('.navbar-collapse').collapse('hide');
    }
  });
</script>
</body>
</html>
<?php
// Close database connection
$conn->close();
?>