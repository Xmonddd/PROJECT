<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "agrishop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $post_id = $_POST['post_id'];
    $new_status = $_POST['status'];

    // Determine where to redirect after update
    $redirect_url = isset($_POST['redirect_url']) ? $_POST['redirect_url'] : (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php');

    // Prepare SQL based on status
    if ($new_status === "Sold") {
        $stmt = $conn->prepare("UPDATE posts SET status = ?, sold_at = NOW() WHERE id = ?");
    } else {
        $stmt = $conn->prepare("UPDATE posts SET status = ?, sold_at = NULL WHERE id = ?");
    }

    $stmt->bind_param("si", $new_status, $post_id);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: " . $redirect_url . "?status_updated=true");
        exit;
    } else {
        echo "Error updating status: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>
